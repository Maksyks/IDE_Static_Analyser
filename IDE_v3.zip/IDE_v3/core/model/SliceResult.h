// core/model/SliceResult.h
#pragma once
#include <QString>
#include <QMap>
#include <QPair>
#include <QMetaType>

struct SliceResult {
    QString custom;      // видимые строки исходника (срез)
    QString llvm2c;      // декомпилят
    QString dotVisible;  // DOT-граф «видимых строк»
    QString dotCfg;      // DOT CFG
    QMap<int, QPair<QString,int>> lineMap; // outLine -> {file, srcLine}
};
Q_DECLARE_METATYPE(SliceResult)
